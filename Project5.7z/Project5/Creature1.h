#pragma once
//0     0
//(0   0)---
//( o )u u \
