#pragma once
//()   ()
//(x  x)^^^^
//( x )====