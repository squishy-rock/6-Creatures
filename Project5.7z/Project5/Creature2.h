#pragma once
//^   ^
//(- -)-----
//( u )c c \