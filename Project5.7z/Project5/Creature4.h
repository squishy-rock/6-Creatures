#pragma once
//$    $
//($  $)----
//( n )n n )