#pragma once
//%    %
//(> < )~~~~
//=o = \/ \/